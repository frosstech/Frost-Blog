<script type="text/javascript">
window.onload = function(){ 
	var submitbutton = document.getElementById("search-text");
	if(submitbutton.addEventListener){
		submitbutton.addEventListener("click", function() {
			if (submitbutton.value == 'Search our Website'){
				submitbutton.value = " ";
			}
		});
	}
}
</script>